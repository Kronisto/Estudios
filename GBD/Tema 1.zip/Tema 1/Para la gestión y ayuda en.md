Estos **SI** para la gestión, ya que se estan haciendo tareas repetitivas o habituales: 
	• Datos voluminosos 
    • Propios, elementales y homogéneos 
    • Pocas interrelaciones y simples 
    • Muchas salidas normalizadas 
    • Procesos sencillos y periódicos 
    • Predomina el tratamiento secuencial y por lotes.
 
**SI** para la toma de decisiones, dirigidos a los directivos de las empresas (*Global*). Características:
	• Datos muy poco voluminosos 
	• Propios y ajenos, agregados y muy heterogéneos 
	• Muchas interrelaciones complejas
	• Pocas salidas, con información significativa, oportuna y fácil de interpretar.
	• Tratamiento no secuencial e interactivo
   
   ![[Pasted image 20221105145357.png]]