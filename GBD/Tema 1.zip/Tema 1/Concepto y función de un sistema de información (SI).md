#GBD

Conjunto de elementos ordenadamente relacionados entre sí de acuerdo a ciertas reglas, que aportan a la organización a la que sirven la información necesaria para el cumplimiento de sus fines. 

==Funciones== -->recogida, procesamiento y almacenamiento de datos y facilitando la recuperación elaboración y presentación de los mismos.

__SI mecanizado__ aquel que está soportado por un ordenador (___SI__ siempre hará referencia a un __SI mecanizado___). 

Entre el __SI__ y el organismo donde está inserto existe una mutua y estrecha interrelación, el __SI__ es un subsistema de los varios que integran la organización. Si no existe la debida interacción y se produce un desfase entre ambos, el __SI__ no podrá cumplir los objetivos para los que fue diseñado.