Un fichero es la representación de una entidad, en cada fichero se guarda la información correspondiente a una de las entidades representadas. 



