#GBD 

• Contenido: los datos y su definición.
		◦ Referenciales 
        ◦ Factuales 
            ▪ Estructurados 
            ▪ No estructurados 

• Equipo físico: el ordenador soporte de información 

• Equipo lógico: sistema de comunicaciones, sistema de gestión de base de datos, etc.

• Administrador: persona o equipo, responsables de asegurar la calidad y disponibilidad de los datos 

• Usuarios 

__SI referencial__: contienen referencias bibliográficas de los documentos dónde se puede encontrar la información, pero no la información en sí misma. 

__SI factual__: devuelven la información buscada, la cual puede ser directamente utilizada. Según su formato
    • ==estructurados== tipo de dato que siguen la misma estructura, todos tenemos nombre, DNI...
    • ==no estructurados== (_formato no fijo, ej.: textos, datos multimedia_)
    
Se suele distinguir entre 2 tipos de sistemas de gestión: 
    • __Sistemas de Gestión de Bases de Datos (_SGBD_)__: tratamiento de datos estructurados. 
    • __Sistemas de Recuperación de Información (_SRI_)__: tratamiento de datos no estructurados.